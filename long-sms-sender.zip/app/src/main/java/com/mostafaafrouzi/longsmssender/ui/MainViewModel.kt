package com.mostafaafrouzi.longsmssender.ui

import android.app.Application
import android.app.PendingIntent
import android.content.Intent
import android.telephony.SmsMessage
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.mostafaafrouzi.longsmssender.data.model.Contact
import com.mostafaafrouzi.longsmssender.data.repository.ContactRepository
import com.mostafaafrouzi.longsmssender.data.repository.SmsRepository
import com.mostafaafrouzi.longsmssender.utils.NumberValidator
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = ContactRepository(application)
    private val smsRepository = SmsRepository(application)

    private val _contacts = MutableLiveData<List<Contact>>()
    val contacts: LiveData<List<Contact>> = _contacts

    private val _selectedIds = MutableLiveData<Set<String>>(emptySet())
    val selectedIds: LiveData<Set<String>> = _selectedIds

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading
    
    private val _segmentCount = MutableLiveData<String>()
    val segmentCount: LiveData<String> = _segmentCount
    
    private val _sendStatus = MutableLiveData<String>()
    val sendStatus: LiveData<String> = _sendStatus

    fun loadContacts() {
        _isLoading.value = true
        viewModelScope.launch {
            val list = repository.getContacts()
            _contacts.postValue(list)
            _isLoading.postValue(false)
        }
    }

    fun toggleSelection(contact: Contact) {
        val current = _selectedIds.value.orEmpty().toMutableSet()
        if (current.contains(contact.id)) {
            current.remove(contact.id)
        } else {
            current.add(contact.id)
        }
        _selectedIds.value = current
    }

    fun selectAll() {
        val allIds = _contacts.value?.map { it.id }?.toSet() ?: emptySet()
        _selectedIds.value = allIds
    }

    fun clearSelection() {
        _selectedIds.value = emptySet()
    }
    
    fun onMessageTextChanged(text: String) {
        if (text.isEmpty()) {
            _segmentCount.value = "0 segments (0 chars)"
            return
        }
        val result = SmsMessage.calculateLength(text, false)
        _segmentCount.value = "${result[0]} segments (${result[2]} chars left)"
    }
    
    fun sendSms(manualNumber: String, message: String) {
        if (message.isBlank()) {
            _sendStatus.value = "Message is empty"
            return
        }

        val recipients = ArrayList<String>()
        
        // Add manual number if valid
        if (NumberValidator.isValidPhoneNumber(manualNumber)) {
            recipients.add(NumberValidator.normalizeNumber(manualNumber))
        }
        
        // Add selected contacts
        val selected = _selectedIds.value.orEmpty()
        _contacts.value?.filter { selected.contains(it.id) }?.forEach { 
            recipients.add(it.normalizedNumber)
        }
        
        if (recipients.isEmpty()) {
            _sendStatus.value = "No valid recipients"
            return
        }
        
        _sendStatus.value = "Sending to ${recipients.size} recipients..."
        
        val context = getApplication<Application>()
        val sentIntent = PendingIntent.getBroadcast(
            context, 0, Intent("SMS_SENT"), PendingIntent.FLAG_IMMUTABLE
        )
        val deliveryIntent = PendingIntent.getBroadcast(
            context, 0, Intent("SMS_DELIVERED"), PendingIntent.FLAG_IMMUTABLE
        )
        
        viewModelScope.launch {
            recipients.forEach { number ->
                smsRepository.sendSms(number, message, sentIntent, deliveryIntent)
            }
            _sendStatus.postValue("Sent to ${recipients.size} recipients")
            clearSelection()
        }
    }
}
