package com.mostafaafrouzi.longsmssender.data.repository

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.telephony.SmsManager
import android.util.Log

class SmsRepository(private val context: Context) {

    private val smsManager: SmsManager by lazy {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            context.getSystemService(SmsManager::class.java) ?: SmsManager.getDefault()
        } else {
            SmsManager.getDefault()
        }
    }

    fun sendSms(
        destinationAddress: String,
        message: String,
        sentIntent: PendingIntent?,
        deliveryIntent: PendingIntent?
    ) {
        try {
            val parts = smsManager.divideMessage(message)
            
            // If it's a single part, we could use sendTextMessage, but sendMultipartTextMessage 
            // handles single parts correctly too and ensures consistency for "Long SMS".
            // However, to be absolutely safe and follow standard practices:
            if (parts.size > 1) {
                val sentIntents = ArrayList<PendingIntent>()
                val deliveryIntents = ArrayList<PendingIntent>()
                
                for (i in parts.indices) {
                    sentIntents.add(sentIntent!!) // Reusing intent for now, ideally unique per part
                    deliveryIntents.add(deliveryIntent!!)
                }
                
                smsManager.sendMultipartTextMessage(
                    destinationAddress,
                    null,
                    parts,
                    sentIntents,
                    deliveryIntents
                )
            } else {
                smsManager.sendTextMessage(
                    destinationAddress,
                    null,
                    message,
                    sentIntent,
                    deliveryIntent
                )
            }
        } catch (e: Exception) {
            Log.e("SmsRepository", "Error sending SMS: ${e.message}")
            // In a real app, we would propagate this error up
        }
    }

    fun calculateLength(message: String): IntArray {
        // Returns: [msgCount, codeUnitCount, codeUnitsRemaining, codeUnitSize]
        // msgCount = number of SMS segments
        return SmsManager.getDefault().divideMessage(message).let { parts ->
             // This is a simplified calculation because divideMessage doesn't give remaining chars directly easily
             // without using the internal logic. 
             // But SmsMessage.calculateLength() is better for UI.
             // However, calculateLength is static on SmsMessage.
             // Let's use a wrapper in ViewModel or here.
             intArrayOf(parts.size, 0, 0, 0) // Placeholder, we will use SmsMessage in ViewModel
        }
    }
}
