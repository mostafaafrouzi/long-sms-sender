package com.mostafaafrouzi.longsmssender.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.mostafaafrouzi.longsmssender.data.model.Contact
import com.mostafaafrouzi.longsmssender.databinding.ItemContactBinding

class ContactAdapter(
    private val onItemClick: (Contact) -> Unit
) : ListAdapter<Contact, ContactAdapter.ContactViewHolder>(ContactDiffCallback()) {

    private var selectedIds = setOf<String>()

    fun updateSelection(newSelection: Set<String>) {
        selectedIds = newSelection
        notifyDataSetChanged() // For simplicity in this phase, efficient partial updates can be done later
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ContactViewHolder {
        val binding = ItemContactBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ContactViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ContactViewHolder, position: Int) {
        val contact = getItem(position)
        holder.bind(contact, selectedIds.contains(contact.id))
    }

    inner class ContactViewHolder(private val binding: ItemContactBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(contact: Contact, isSelected: Boolean) {
            binding.txtName.text = contact.name
            binding.txtNumber.text = contact.phoneNumber
            binding.checkbox.isChecked = isSelected
            
            binding.root.setOnClickListener {
                onItemClick(contact)
            }
            binding.checkbox.setOnClickListener { 
                onItemClick(contact)
            }
        }
    }

    class ContactDiffCallback : DiffUtil.ItemCallback<Contact>() {
        override fun areItemsTheSame(oldItem: Contact, newItem: Contact): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: Contact, newItem: Contact): Boolean {
            return oldItem == newItem
        }
    }
}
