package com.mostafaafrouzi.longsmssender

import android.app.Application

class LongSmsApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Initialize things here if needed
    }
}
