package com.mostafaafrouzi.longsmssender.ui

import android.content.ClipboardManager
import android.content.Context
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mostafaafrouzi.longsmssender.R
import com.mostafaafrouzi.longsmssender.utils.PermissionManager
import com.mostafaafrouzi.longsmssender.utils.SmsBroadcastReceiver

class MainActivity : AppCompatActivity() {

    private val viewModel: MainViewModel by viewModels()
    private val smsReceiver = SmsBroadcastReceiver()
    private lateinit var contactAdapter: ContactAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Register Receiver
        ContextCompat.registerReceiver(
            this,
            smsReceiver,
            IntentFilter().apply {
                addAction("SMS_SENT")
                addAction("SMS_DELIVERED")
            },
            ContextCompat.RECEIVER_NOT_EXPORTED
        )

        setupUI()
        observeViewModel()
    }

    private fun setupUI() {
        // Toolbar & Load Contacts
        findViewById<Button>(R.id.btnLoadContacts).setOnClickListener {
            checkAndRequestPermissions()
        }

        // RecyclerView
        val recyclerContacts = findViewById<RecyclerView>(R.id.recyclerContacts)
        contactAdapter = ContactAdapter { contact ->
            viewModel.toggleSelection(contact)
        }
        recyclerContacts.layoutManager = LinearLayoutManager(this)
        recyclerContacts.adapter = contactAdapter

        // Selection Controls
        findViewById<Button>(R.id.btnSelectAll).setOnClickListener { viewModel.selectAll() }
        findViewById<Button>(R.id.btnClearSelection).setOnClickListener { viewModel.clearSelection() }

        // Input Area
        val edtPhone = findViewById<EditText>(R.id.edtPhone)
        val edtMessage = findViewById<EditText>(R.id.edtMessage)
        val btnSend = findViewById<Button>(R.id.btnSend)
        val btnPaste = findViewById<ImageButton>(R.id.btnPaste)

        btnSend.setOnClickListener {
            val phone = edtPhone.text.toString()
            val message = edtMessage.text.toString()
            viewModel.sendSms(phone, message)
        }

        btnPaste.setOnClickListener {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            if (clipboard.hasPrimaryClip()) {
                val item = clipboard.primaryClip?.getItemAt(0)
                val text = item?.text
                if (!text.isNullOrEmpty()) {
                    val start = Math.max(edtMessage.selectionStart, 0)
                    val end = Math.max(edtMessage.selectionEnd, 0)
                    edtMessage.text.replace(Math.min(start, end), Math.max(start, end), text)
                }
            }
        }

        edtMessage.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                viewModel.onMessageTextChanged(s.toString())
            }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun observeViewModel() {
        val txtStatus = findViewById<TextView>(R.id.txtStatus)
        val txtSegment = findViewById<TextView>(R.id.txtSegment)
        val txtSelectionStatus = findViewById<TextView>(R.id.txtSelectionStatus)

        viewModel.contacts.observe(this) { contacts ->
            contactAdapter.submitList(contacts)
            if (contacts.isNotEmpty()) {
                txtStatus.text = getString(R.string.status_loaded, contacts.size)
            }
        }

        viewModel.selectedIds.observe(this) { selected ->
            contactAdapter.updateSelection(selected)
            txtSelectionStatus.text = "${selected.size} selected"
        }

        viewModel.segmentCount.observe(this) { count ->
            txtSegment.text = count
        }
        
        viewModel.sendStatus.observe(this) { status ->
            txtStatus.text = status
        }
    }

    private fun checkAndRequestPermissions() {
        if (PermissionManager.hasPermissions(this)) {
            viewModel.loadContacts()
        } else {
            if (PermissionManager.shouldShowRationale(this)) {
                showRationaleDialog()
            } else {
                PermissionManager.requestPermissions(this)
            }
        }
    }

    private fun showRationaleDialog() {
        AlertDialog.Builder(this)
            .setTitle(R.string.permission_rationale_title)
            .setMessage(R.string.permission_rationale_message)
            .setPositiveButton(R.string.grant) { _, _ ->
                PermissionManager.requestPermissions(this)
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(smsReceiver)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PermissionManager.PERMISSION_REQUEST_CODE) {
            if (grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
                viewModel.loadContacts()
            } else {
                Toast.makeText(this, R.string.permissions_denied, Toast.LENGTH_SHORT).show()
            }
        }
    }
}
